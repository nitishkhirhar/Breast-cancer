# breast-cancer-detection-using-cnn

## Nitish Kumar


```python
!pip install tensorflow
```

    Requirement already satisfied: tensorflow in c:\users\subhash kumar\anaconda3\lib\site-packages (2.11.0)
    Requirement already satisfied: tensorflow-intel==2.11.0; platform_system == "Windows" in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow) (2.11.0)
    Requirement already satisfied: tensorboard<2.12,>=2.11 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.11.0)
    Requirement already satisfied: astunparse>=1.6.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.6.3)
    Requirement already satisfied: packaging in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (20.4)
    Requirement already satisfied: six>=1.12.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.15.0)
    Requirement already satisfied: tensorflow-io-gcs-filesystem>=0.23.1; platform_machine != "arm64" or platform_system != "Darwin" in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.27.0)
    Requirement already satisfied: libclang>=13.0.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (14.0.6)
    Requirement already satisfied: setuptools in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (49.2.0.post20200714)
    Requirement already satisfied: google-pasta>=0.1.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.2.0)
    Requirement already satisfied: tensorflow-estimator<2.12,>=2.11.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.11.0)
    Requirement already satisfied: numpy>=1.20 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.23.4)
    Requirement already satisfied: termcolor>=1.1.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.1.0)
    Requirement already satisfied: keras<2.12,>=2.11.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.11.0)
    Requirement already satisfied: h5py>=2.9.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.10.0)
    Requirement already satisfied: opt-einsum>=2.3.2 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.3.0)
    Requirement already satisfied: gast<=0.4.0,>=0.2.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.4.0)
    Requirement already satisfied: flatbuffers>=2.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (22.10.26)
    Requirement already satisfied: typing-extensions>=3.6.6 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.7.4.2)
    Requirement already satisfied: protobuf<3.20,>=3.9.2 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.19.6)
    Requirement already satisfied: grpcio<2.0,>=1.24.3 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.50.0)
    Requirement already satisfied: wrapt>=1.11.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.11.2)
    Requirement already satisfied: absl-py>=1.0.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.3.0)
    Requirement already satisfied: markdown>=2.6.8 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.4.1)
    Requirement already satisfied: google-auth-oauthlib<0.5,>=0.4.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.4.6)
    Requirement already satisfied: google-auth<3,>=1.6.3 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.14.1)
    Requirement already satisfied: tensorboard-data-server<0.7.0,>=0.6.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.6.1)
    Requirement already satisfied: wheel>=0.26 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.34.2)
    Requirement already satisfied: werkzeug>=1.0.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.0.1)
    Requirement already satisfied: requests<3,>=2.21.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.24.0)
    Requirement already satisfied: tensorboard-plugin-wit>=1.6.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.8.1)
    Requirement already satisfied: pyparsing>=2.0.2 in c:\users\subhash kumar\anaconda3\lib\site-packages (from packaging->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.4.7)
    Requirement already satisfied: importlib-metadata>=4.4; python_version < "3.10" in c:\users\subhash kumar\anaconda3\lib\site-packages (from markdown>=2.6.8->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (4.11.4)
    Requirement already satisfied: requests-oauthlib>=0.7.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from google-auth-oauthlib<0.5,>=0.4.1->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.3.1)
    Requirement already satisfied: rsa<5,>=3.1.4; python_version >= "3.6" in c:\users\subhash kumar\anaconda3\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (4.9)
    Requirement already satisfied: pyasn1-modules>=0.2.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.2.8)
    Requirement already satisfied: cachetools<6.0,>=2.0.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from google-auth<3,>=1.6.3->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (5.2.0)
    Requirement already satisfied: idna<3,>=2.5 in c:\users\subhash kumar\anaconda3\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2.10)
    Requirement already satisfied: certifi>=2017.4.17 in c:\users\subhash kumar\anaconda3\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (2020.6.20)
    Requirement already satisfied: chardet<4,>=3.0.2 in c:\users\subhash kumar\anaconda3\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.0.4)
    Requirement already satisfied: urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 in c:\users\subhash kumar\anaconda3\lib\site-packages (from requests<3,>=2.21.0->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (1.25.9)
    Requirement already satisfied: zipp>=0.5 in c:\users\subhash kumar\anaconda3\lib\site-packages (from importlib-metadata>=4.4; python_version < "3.10"->markdown>=2.6.8->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.8.0)
    Requirement already satisfied: oauthlib>=3.0.0 in c:\users\subhash kumar\anaconda3\lib\site-packages (from requests-oauthlib>=0.7.0->google-auth-oauthlib<0.5,>=0.4.1->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (3.2.2)
    Requirement already satisfied: pyasn1>=0.1.3 in c:\users\subhash kumar\anaconda3\lib\site-packages (from rsa<5,>=3.1.4; python_version >= "3.6"->google-auth<3,>=1.6.3->tensorboard<2.12,>=2.11->tensorflow-intel==2.11.0; platform_system == "Windows"->tensorflow) (0.4.8)
    


```python
!pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\users\subhash kumar\anaconda3\lib\site-packages (4.6.0.66)
    Requirement already satisfied: numpy>=1.14.5; python_version >= "3.7" in c:\users\subhash kumar\anaconda3\lib\site-packages (from opencv-python) (1.23.4)
    


```python
#importing necissary libraries

from numpy.random import seed
seed(101)

import pandas as pd
import numpy as np

import tensorflow

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.metrics import categorical_crossentropy
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint

import os
from os import listdir
import cv2

import imageio
import skimage
import skimage.io
import skimage.transform

from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from skimage.io import imread
import itertools
import shutil
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```

## Exploring the Data Structure


```python
files = listdir("../input/data/")
print(len(files))
```

    1
    


```python
#looking at first 10 folders
files[0:1]
```




    ['8863']



#### In each folder there are several images and each folder name is the id of the patient


```python
base_path = "../input/data/"
folder = listdir(base_path)
print("No. of Patients:",len(folder))
```

    No. of Patients: 1
    

#### We have to find the number of total images in the dataset


```python
total_images = 0
for n in range(len(folder)):
    patient_id = folder[n]
    for c in [0, 1]:
        patient_path = base_path + patient_id
        class_path = patient_path + '/' + str(c) + '/'
        subfiles = listdir(class_path)
        total_images += len(subfiles)
        
print("Total Images in dataset: ", total_images )
```

    Total Images in dataset:  979
    

#### Organizing the data into pandas data frame


```python
data = pd.DataFrame(index=np.arange(0, total_images), columns=["patient_id", "path", "target"])

k = 0
for n in range(len(folder)):
    patient_id = folder[n]
    patient_path = base_path + patient_id 
    for c in [0,1]:
        class_path = patient_path + "/" + str(c) + "/"
        subfiles = listdir(class_path)
        for m in range(len(subfiles)):
            image_path = subfiles[m]
            data.iloc[k]["path"] = class_path + image_path
            data.iloc[k]["target"] = c
            data.iloc[k]["patient_id"] = patient_id
            k += 1  

data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>patient_id</th>
      <th>path</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8863</td>
      <td>../input/data/8863/0/8863_idx5_x1001_y1001_cla...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8863</td>
      <td>../input/data/8863/0/8863_idx5_x1001_y1051_cla...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8863</td>
      <td>../input/data/8863/0/8863_idx5_x1001_y1101_cla...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8863</td>
      <td>../input/data/8863/0/8863_idx5_x1001_y1151_cla...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8863</td>
      <td>../input/data/8863/0/8863_idx5_x1001_y1201_cla...</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



#### Shape of data frame[](http://)


```python
data.shape
```




    (979, 3)



## Exploring the data


```python
cancer_perc = data.groupby("patient_id").target.value_counts() / data.groupby("patient_id").target.size()
canxer_perc = cancer_perc.unstack()

fig, ax = plt.subplots(1, 3,figsize = (20,5))
sns.distplot(data.groupby('patient_id').size(), ax=ax[0], color='Orange', kde=False, bins=30)
ax[0].set_xlabel('Number of patches')
ax[0].set_ylabel('Frequency')
ax[0].set_title('how may patches do we have per patient?')
sns.distplot(cancer_perc.loc[:, 1]*100, ax=ax[1], color="Tomato", kde=False, bins=30)
ax[1].set_title("How much percentage of an image is covered by IDC?")
ax[1].set_ylabel("Frequency")
ax[1].set_xlabel("% of patches with IDC");
sns.countplot(data.target, palette="Set2", ax=ax[2]);
ax[2].set_xlabel("no(0) versus yes(1)")
ax[2].set_title("How many patches show IDC?");

```


![png](output_17_0.png)


### Insights

* The numbe rof image patches per patient varie's a lot.

* Some patients have more than 80 % patches that show IDC! Consequently the tissue is full of cancer or only a part of the breast was covered by the tissue slice that is focused on the IDC cancer. 

* The classes of IDC versus no IDC are imbalanced.


```python
# coverting target to int
data.target = data.target.astype(np.int)
```

    <ipython-input-25-8a57bb4045d9>:2: DeprecationWarning: `np.int` is a deprecated alias for the builtin `int`. To silence this warning, use `int` by itself. Doing this will not modify any behavior and is safe. When replacing `np.int`, you may wish to use e.g. `np.int64` or `np.int32` to specify the precision. If you wish to review your current use, check the release note link for additional information.
    Deprecated in NumPy 1.20; for more details and guidance: https://numpy.org/devdocs/release/1.20.0-notes.html#deprecations
      data.target = data.target.astype(np.int)
    

### Displaying Cnacer Tissue Samples


```python
cancer_selection = np.random.choice(data[data.target == 1].index.values, size=50, replace=False)

fig, ax = plt.subplots(5, 10, figsize=(20, 10))

for n in range(5):
    for m in range(10):
        idx = cancer_selection[m + 10*n]
        image = imread(data.loc[idx, "path"])
        ax[n,m].imshow(image)
        ax[n,m].grid(False)

```


![png](output_21_0.png)


### Displaying Non-Cnacer Tissue Samples


```python
non_cancer_selection = np.random.choice(data[data.target == 0].index.values, size=50, replace=False)

fig, ax = plt.subplots(5, 10, figsize=(20, 10))

for n in range(5):
    for m in range(10):
        idx = non_cancer_selection[m + 10*n]
        image = imread(data.loc[idx, "path"])
        ax[n,m].imshow(image)
        ax[n,m].grid(False)
```


![png](output_23_0.png)


### Insights

* Cancer Tissur appears to be more viloet.

* But some non-caner tissue is also violet.


## Preparing the dataset


```python
# Creating diresctory to store all images
all_images_dir = 'all_images_dir'

if os.path.isdir(all_images_dir):
    pass
else:
    os.mkdir(all_images_dir)
    

```


```python
# This code copies all images from their seperate folders into the same 
# folder called all_images_dir.

'''
The directory structure is like:
    patient_id:
                0
                1
'''

patient_list = folder

for patient in patient_list:
    
    path_0 = "../input/data/" + str(patient) + '/0'
    path_1 = "../input/data/" + str(patient) + '/1'
    
    # create list of all files in folder 0
    file_list_0 = listdir(path_0)
    
    #create a list of all files in folder 1
    file_list_1 = listdir(path_1)
    
    # moving the 0 class images to all_images_dir
    for fname in file_list_0:
        
        src = os.path.join(path_0, fname)
        dst = os.path.join(all_images_dir, fname)
        shutil.copyfile(src, dst)
        
    # moving the 1 class images to all_images_dir
    for fname in file_list_1:
        
        src = os.path.join(path_1, fname)
        dst = os.path.join(all_images_dir, fname)
        shutil.copyfile(src, dst)
        
    
        
```


```python
# Total number of images
len(listdir(all_images_dir))
```




    979



### Creating dataframe of all images


```python
image_list = os.listdir('all_images_dir')
df_data = pd.DataFrame(image_list, columns=['image_id'])

df_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>image_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8863_idx5_x1001_y1001_class0.png</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8863_idx5_x1001_y1051_class0.png</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8863_idx5_x1001_y1101_class0.png</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8863_idx5_x1001_y1151_class0.png</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8863_idx5_x1001_y1201_class0.png</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Defining helper functions

def extract_patient_id(x):
    
    a = x.split('_')
    patient_id = a[0]
    
    return patient_id

def extract_target(x):
    
    a = x.split('_')
    b = a[4]
    target = b[5]
    
    return target

# creating new column named patient_id
df_data['patient_id'] = df_data['image_id'].apply(extract_patient_id)

#creating new column named target
df_data['target'] = df_data['image_id'].apply(extract_target)

df_data.head(10)

    
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>image_id</th>
      <th>patient_id</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8863_idx5_x1001_y1001_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8863_idx5_x1001_y1051_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8863_idx5_x1001_y1101_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8863_idx5_x1001_y1151_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8863_idx5_x1001_y1201_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>8863_idx5_x1001_y1251_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8863_idx5_x1001_y1301_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8863_idx5_x1001_y1351_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8863_idx5_x1001_y1401_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>8863_idx5_x1001_y1451_class0.png</td>
      <td>8863</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# class distribution of the images

df_data['target'].value_counts()
```




    0    772
    1    207
    Name: target, dtype: int64



### Balance the class distribution

* We can see that the class 1 images are higher in number that of class 0

* So to prevent this we balance the dataset

* We do this so that the Neural Network dose not lean on favouring only one class 


```python
SAMPLE_SIZE = 207

# take a sample of the majority class 0 (total = 198738)
df_0 = df_data[df_data['target'] == '0'].sample(SAMPLE_SIZE, random_state=101)
# take a sample of class 1 (total = 207)
df_1 = df_data[df_data['target'] == '1'].sample(SAMPLE_SIZE, random_state=101)

# concat the two dataframes
df_data = pd.concat([df_0, df_1], axis=0).reset_index(drop=True)

# Check the new class distribution
df_data['target'].value_counts()
```




    1    207
    0    207
    Name: target, dtype: int64



### Creating train and test sets


```python
y = df_data['target']

df_train, df_val = train_test_split(df_data, test_size=0.10, random_state=101, stratify=y)

print(df_train.shape)
print(df_val.shape)
```

    (372, 3)
    (42, 3)
    

### Creating Directory Structure


```python
# Creating new base directory
base_dir ='base_dir'
os.mkdir(base_dir)

# Creating train directory inside base directory
train_dir = os.path.join(base_dir, 'train_dir')
os.mkdir(train_dir)

# Creating validation directory inside base directory
val_dir = os.path.join(base_dir, 'val_dir')
os.mkdir(val_dir)

# create new folders inside train_dir
a_no_idc = os.path.join(train_dir, 'a_no_idc')
os.mkdir(a_no_idc)
b_has_idc = os.path.join(train_dir, 'b_has_idc')
os.mkdir(b_has_idc)


# create new folders inside val_dir
a_no_idc = os.path.join(val_dir, 'a_no_idc')
os.mkdir(a_no_idc)
b_has_idc = os.path.join(val_dir, 'b_has_idc')
os.mkdir(b_has_idc)



```


```python
# check that the folders have been created
os.listdir('base_dir/train_dir')
```




    ['a_no_idc', 'b_has_idc']




```python
# Set the id as the index in df_data
df_data.set_index('image_id', inplace=True)
```


```python
train_list = list(df_train['image_id'])
val_list = list(df_val['image_id'])

# Transfering the train images
for image in train_list:

    try: 
        fname = image
        target = df_data.loc[image, 'target']

        if target == '0':
            label = 'a_no_idc'
        if target == '1':
            label = 'b_has_idc'

        # source path to image
        src = os.path.join(all_images_dir, fname)
        # destination path to image
        dst = os.path.join(train_dir, label, fname)
        # move the image from the source to the destination
        shutil.move(src, dst)
    except: 
        continue

for image in val_list:

    try: 
        fname = image
        target = df_data.loc[image,'target']

        if target == '0':
            label = 'a_no_idc'
        if target == '1':
            label = 'b_has_idc'


        # source path to image
        src = os.path.join(all_images_dir, fname)
        # destination path to image
        dst = os.path.join(val_dir, label, fname)
        # move the image from the source to the destination
        shutil.move(src, dst)

    except:
        continue

        
```


```python
# check how many val images we have in each folder
print(len(os.listdir('base_dir/train_dir/a_no_idc')))
print(len(os.listdir('base_dir/train_dir/b_has_idc')))
```

    186
    186
    

### Setting up image generators


```python
train_path = 'base_dir/train_dir'
valid_path = 'base_dir/val_dir'

num_train_samples = len(df_train)
num_val_samples = len(df_val)
train_batch_size = 10
val_batch_size = 10

train_steps = np.ceil(num_train_samples / train_batch_size)
val_steps = np.ceil(num_val_samples / val_batch_size)
```


```python
IMAGE_SIZE = 50
```


```python

datagen = ImageDataGenerator(rescale = 1.0 / 255,
                             rotation_range = 90,
                             zoom_range = 0.2,
                             horizontal_flip=True,
                             vertical_flip=True)

train_gen = datagen.flow_from_directory(train_path,
                                        target_size=(IMAGE_SIZE,IMAGE_SIZE),
                                        batch_size=train_batch_size,
                                        class_mode='categorical')

val_gen = datagen.flow_from_directory(valid_path,
                                        target_size=(IMAGE_SIZE,IMAGE_SIZE),
                                        batch_size=val_batch_size,
                                        class_mode='categorical')

# Note: shuffle=False causes the test dataset to not be shuffled
test_gen = datagen.flow_from_directory(valid_path,
                                        target_size=(IMAGE_SIZE,IMAGE_SIZE),
                                        batch_size=1,
                                        class_mode='categorical',
                                        shuffle=False)
```

    Found 372 images belonging to 2 classes.
    Found 42 images belonging to 2 classes.
    Found 42 images belonging to 2 classes.
    


```python
# Building the model
kernel_size = (3,3)
pool_size= (2,2)
first_filters = 32
second_filters = 64
third_filters = 128

dropout_conv = 0.3
dropout_dense = 0.3


model = Sequential()
model.add(Conv2D(first_filters, kernel_size, activation = 'relu', 
                 input_shape = (IMAGE_SIZE, IMAGE_SIZE, 3)))
model.add(Conv2D(first_filters, kernel_size, activation = 'relu'))
model.add(Conv2D(first_filters, kernel_size, activation = 'relu'))
model.add(MaxPooling2D(pool_size = pool_size)) 
model.add(Dropout(dropout_conv))

model.add(Conv2D(second_filters, kernel_size, activation ='relu'))
model.add(Conv2D(second_filters, kernel_size, activation ='relu'))
model.add(Conv2D(second_filters, kernel_size, activation ='relu'))
model.add(MaxPooling2D(pool_size = pool_size))
model.add(Dropout(dropout_conv))

model.add(Conv2D(third_filters, kernel_size, activation ='relu'))
model.add(Conv2D(third_filters, kernel_size, activation ='relu'))
model.add(Conv2D(third_filters, kernel_size, activation ='relu'))
model.add(MaxPooling2D(pool_size = pool_size))
model.add(Dropout(dropout_conv))

model.add(Flatten())
model.add(Dense(256, activation = "relu"))
model.add(Dropout(dropout_dense))
model.add(Dense(2, activation = "softmax"))

model.summary()
```

    Model: "sequential"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     conv2d (Conv2D)             (None, 48, 48, 32)        896       
                                                                     
     conv2d_1 (Conv2D)           (None, 46, 46, 32)        9248      
                                                                     
     conv2d_2 (Conv2D)           (None, 44, 44, 32)        9248      
                                                                     
     max_pooling2d (MaxPooling2D  (None, 22, 22, 32)       0         
     )                                                               
                                                                     
     dropout (Dropout)           (None, 22, 22, 32)        0         
                                                                     
     conv2d_3 (Conv2D)           (None, 20, 20, 64)        18496     
                                                                     
     conv2d_4 (Conv2D)           (None, 18, 18, 64)        36928     
                                                                     
     conv2d_5 (Conv2D)           (None, 16, 16, 64)        36928     
                                                                     
     max_pooling2d_1 (MaxPooling  (None, 8, 8, 64)         0         
     2D)                                                             
                                                                     
     dropout_1 (Dropout)         (None, 8, 8, 64)          0         
                                                                     
     conv2d_6 (Conv2D)           (None, 6, 6, 128)         73856     
                                                                     
     conv2d_7 (Conv2D)           (None, 4, 4, 128)         147584    
                                                                     
     conv2d_8 (Conv2D)           (None, 2, 2, 128)         147584    
                                                                     
     max_pooling2d_2 (MaxPooling  (None, 1, 1, 128)        0         
     2D)                                                             
                                                                     
     dropout_2 (Dropout)         (None, 1, 1, 128)         0         
                                                                     
     flatten (Flatten)           (None, 128)               0         
                                                                     
     dense (Dense)               (None, 256)               33024     
                                                                     
     dropout_3 (Dropout)         (None, 256)               0         
                                                                     
     dense_1 (Dense)             (None, 2)                 514       
                                                                     
    =================================================================
    Total params: 514,306
    Trainable params: 514,306
    Non-trainable params: 0
    _________________________________________________________________
    

### Training the model


```python
model.compile(Adam(lr=0.0001), loss='binary_crossentropy', 
              metrics=['accuracy'])
```

    WARNING:absl:`lr` is deprecated, please use `learning_rate` instead, or use the legacy optimizer, e.g.,tf.keras.optimizers.legacy.Adam.
    


```python
filepath = "model.h5"
checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=1, 
                             save_best_only=True, mode='max')

reduce_lr = ReduceLROnPlateau(monitor='val_acc', factor=0.5, patience=3, 
                                   verbose=1, mode='max', min_lr=0.00001)
                              
                              
callbacks_list = [checkpoint, reduce_lr]

history = model.fit_generator(train_gen, steps_per_epoch=train_steps, 
                    validation_data=val_gen,
                    validation_steps=val_steps,
                    epochs=50, verbose=1,
                   callbacks=callbacks_list)

try:
    model.save('/kaggle/working/model.h5')
except:
    pass

try:
    model.save('model.h5')
except:
    pass
```

    <ipython-input-47-8d6535370f1e>:11: UserWarning: `Model.fit_generator` is deprecated and will be removed in a future version. Please use `Model.fit`, which supports generators.
      history = model.fit_generator(train_gen, steps_per_epoch=train_steps,
    

    Epoch 1/50
    38/38 [==============================] - ETA: 0s - loss: 0.6840 - accuracy: 0.5484WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 15s 212ms/step - loss: 0.6840 - accuracy: 0.5484 - val_loss: 0.6937 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 2/50
    38/38 [==============================] - ETA: 0s - loss: 0.6750 - accuracy: 0.5538WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 156ms/step - loss: 0.6750 - accuracy: 0.5538 - val_loss: 0.6094 - val_accuracy: 0.6905 - lr: 0.0010
    Epoch 3/50
    38/38 [==============================] - ETA: 0s - loss: 0.6918 - accuracy: 0.5081WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6918 - accuracy: 0.5081 - val_loss: 0.6942 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 4/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 157ms/step - loss: 0.6939 - accuracy: 0.5000 - val_loss: 0.6917 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 5/50
    38/38 [==============================] - ETA: 0s - loss: 0.6818 - accuracy: 0.5538WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 160ms/step - loss: 0.6818 - accuracy: 0.5538 - val_loss: 0.6305 - val_accuracy: 0.8095 - lr: 0.0010
    Epoch 6/50
    38/38 [==============================] - ETA: 0s - loss: 0.6680 - accuracy: 0.5376WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 155ms/step - loss: 0.6680 - accuracy: 0.5376 - val_loss: 0.6944 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 7/50
    38/38 [==============================] - ETA: 0s - loss: 0.6872 - accuracy: 0.5511WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 158ms/step - loss: 0.6872 - accuracy: 0.5511 - val_loss: 0.6704 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 8/50
    38/38 [==============================] - ETA: 0s - loss: 0.6855 - accuracy: 0.5188WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 158ms/step - loss: 0.6855 - accuracy: 0.5188 - val_loss: 0.6966 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 9/50
    38/38 [==============================] - ETA: 0s - loss: 0.6957 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6957 - accuracy: 0.5000 - val_loss: 0.6937 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 10/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 154ms/step - loss: 0.6938 - accuracy: 0.5000 - val_loss: 0.6935 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 11/50
    38/38 [==============================] - ETA: 0s - loss: 0.6942 - accuracy: 0.4973WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 150ms/step - loss: 0.6942 - accuracy: 0.4973 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 12/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.4543WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6939 - accuracy: 0.4543 - val_loss: 0.6931 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 13/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6936 - accuracy: 0.5027 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 14/50
    38/38 [==============================] - ETA: 0s - loss: 0.6932 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 151ms/step - loss: 0.6932 - accuracy: 0.5027 - val_loss: 0.6931 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 15/50
    38/38 [==============================] - ETA: 0s - loss: 0.6932 - accuracy: 0.5242WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 160ms/step - loss: 0.6932 - accuracy: 0.5242 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 16/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.4731WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 158ms/step - loss: 0.6939 - accuracy: 0.4731 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 17/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.4435WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 154ms/step - loss: 0.6939 - accuracy: 0.4435 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 18/50
    38/38 [==============================] - ETA: 0s - loss: 0.6932 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6932 - accuracy: 0.5027 - val_loss: 0.6931 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 19/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4624WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6938 - accuracy: 0.4624 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 20/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 150ms/step - loss: 0.6931 - accuracy: 0.5000 - val_loss: 0.6931 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 21/50
    38/38 [==============================] - ETA: 0s - loss: 0.6937 - accuracy: 0.4866WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6937 - accuracy: 0.4866 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 22/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.4543WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6939 - accuracy: 0.4543 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 23/50
    38/38 [==============================] - ETA: 0s - loss: 0.6935 - accuracy: 0.5108WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 157ms/step - loss: 0.6935 - accuracy: 0.5108 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 24/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4973WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6938 - accuracy: 0.4973 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 25/50
    38/38 [==============================] - ETA: 0s - loss: 0.6930 - accuracy: 0.4839WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6930 - accuracy: 0.4839 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 26/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.4919WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6936 - accuracy: 0.4919 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 27/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.4866WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6936 - accuracy: 0.4866 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 28/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4919WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 157ms/step - loss: 0.6938 - accuracy: 0.4919 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 29/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6936 - accuracy: 0.5027 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 30/50
    38/38 [==============================] - ETA: 0s - loss: 0.6933 - accuracy: 0.5081WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6933 - accuracy: 0.5081 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 31/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4731WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 151ms/step - loss: 0.6938 - accuracy: 0.4731 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 32/50
    38/38 [==============================] - ETA: 0s - loss: 0.6934 - accuracy: 0.5054WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6934 - accuracy: 0.5054 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 33/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.4624WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 149ms/step - loss: 0.6936 - accuracy: 0.4624 - val_loss: 0.6931 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 34/50
    38/38 [==============================] - ETA: 0s - loss: 0.6939 - accuracy: 0.4570WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 148ms/step - loss: 0.6939 - accuracy: 0.4570 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 35/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.4946WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 152ms/step - loss: 0.6936 - accuracy: 0.4946 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 36/50
    38/38 [==============================] - ETA: 0s - loss: 0.6933 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 157ms/step - loss: 0.6933 - accuracy: 0.5027 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 37/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6931 - accuracy: 0.5000 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 38/50
    38/38 [==============================] - ETA: 0s - loss: 0.6930 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 166ms/step - loss: 0.6930 - accuracy: 0.5027 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 39/50
    38/38 [==============================] - ETA: 0s - loss: 0.6932 - accuracy: 0.5000WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6932 - accuracy: 0.5000 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 40/50
    38/38 [==============================] - ETA: 0s - loss: 0.6934 - accuracy: 0.4973WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 154ms/step - loss: 0.6934 - accuracy: 0.4973 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 41/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.5081WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 149ms/step - loss: 0.6931 - accuracy: 0.5081 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 42/50
    38/38 [==============================] - ETA: 0s - loss: 0.6936 - accuracy: 0.4892WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 151ms/step - loss: 0.6936 - accuracy: 0.4892 - val_loss: 0.6933 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 43/50
    38/38 [==============================] - ETA: 0s - loss: 0.6929 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 149ms/step - loss: 0.6929 - accuracy: 0.5027 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 44/50
    38/38 [==============================] - ETA: 0s - loss: 0.6933 - accuracy: 0.4919WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 151ms/step - loss: 0.6933 - accuracy: 0.4919 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 45/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4946WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6938 - accuracy: 0.4946 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 46/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.4946WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 156ms/step - loss: 0.6931 - accuracy: 0.4946 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 47/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.4919WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 153ms/step - loss: 0.6931 - accuracy: 0.4919 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 48/50
    38/38 [==============================] - ETA: 0s - loss: 0.6935 - accuracy: 0.5027WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 170ms/step - loss: 0.6935 - accuracy: 0.5027 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 49/50
    38/38 [==============================] - ETA: 0s - loss: 0.6931 - accuracy: 0.4892WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 161ms/step - loss: 0.6931 - accuracy: 0.4892 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    Epoch 50/50
    38/38 [==============================] - ETA: 0s - loss: 0.6938 - accuracy: 0.4704WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Can save best model only with val_acc available, skipping.
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    WARNING:tensorflow:Learning rate reduction is conditioned on metric `val_acc` which is not available. Available metrics are: loss,accuracy,val_loss,val_accuracy,lr
    

    38/38 [==============================] - 6s 157ms/step - loss: 0.6938 - accuracy: 0.4704 - val_loss: 0.6932 - val_accuracy: 0.5000 - lr: 0.0010
    


```python
model.save('model.h5')
```

### Evaluating the model


```python
# get the metric names so we can use evaulate_generator
model.metrics_names
```




    ['loss', 'accuracy']




```python
# Here the best epoch will be used.

model.load_weights('model.h5')

val_loss, val_acc = \
model.evaluate_generator(test_gen, 
                        steps=len(df_val))

print('val_loss:', val_loss)
print('val_acc:', val_acc)
```

    <ipython-input-50-28bf2f308882>:6: UserWarning: `Model.evaluate_generator` is deprecated and will be removed in a future version. Please use `Model.evaluate`, which supports generators.
      model.evaluate_generator(test_gen,
    

    val_loss: 0.6931729316711426
    val_acc: 0.5
    

### Plotting the training curves


```python
# display the loss and accuracy curves

import matplotlib.pyplot as plt

acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(1, len(acc) + 1)

plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.legend()
plt.figure()

plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.legend()
plt.figure()
```




    <Figure size 432x288 with 0 Axes>




![png](output_56_1.png)



![png](output_56_2.png)



    <Figure size 432x288 with 0 Axes>


### Make a prediction on the val set
We need these predictions to calculate the AUC score, print the Confusion Matrix and calculate the F1 score.


```python
# make a prediction
predictions = model.predict_generator(test_gen, steps=len(df_val), verbose=1)
```

    <ipython-input-52-94026f275592>:2: UserWarning: `Model.predict_generator` is deprecated and will be removed in a future version. Please use `Model.predict`, which supports generators.
      predictions = model.predict_generator(test_gen, steps=len(df_val), verbose=1)
    

    42/42 [==============================] - 1s 13ms/step
    


```python
predictions.shape
```




    (42, 2)




```python
# This is how to check what index keras has internally assigned to each class. 
test_gen.class_indices
```




    {'a_no_idc': 0, 'b_has_idc': 1}




```python
# Put the predictions into a dataframe.
# The columns need to be oredered to match the output of the previous cell

df_preds = pd.DataFrame(predictions, columns=['no_idc', 'has_idc'])

df_preds.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>no_idc</th>
      <th>has_idc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.507115</td>
      <td>0.492885</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.507115</td>
      <td>0.492885</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.507115</td>
      <td>0.492885</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.507115</td>
      <td>0.492885</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.507115</td>
      <td>0.492885</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Get the true labels
y_true = test_gen.classes

# Get the predicted labels as probabilities
y_pred = df_preds['has_idc']
```

### Calculating the AUC Score


```python
from sklearn.metrics import roc_auc_score

roc_auc_score(y_true, y_pred)
```




    0.5



### Creating the confusion matrix


```python
def plot_confusion_matrix(cm, classes,
                         normalize=False,
                         title='Confusion Matrix',
                         cmap=plt.cm.Blues):
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')
        
    print(cm)
    
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    
        
```


```python
# Get the labels of the test images.

test_labels = test_gen.classes
```


```python
test_labels.shape
```




    (42,)




```python
# argmax returns the index of the max value in a row
cm = confusion_matrix(test_labels, predictions.argmax(axis=1))
```


```python
# Print the label associated with each class
test_gen.class_indices
```




    {'a_no_idc': 0, 'b_has_idc': 1}




```python
# Define the labels of the class indices. These need to match the 
# order shown above.
cm_plot_labels = ['a_no_idc', 'b_has_idc']

plot_confusion_matrix(cm, cm_plot_labels, title='Confusion Matrix')
```

    Confusion matrix, without normalization
    [[21  0]
     [21  0]]
    


![png](output_71_1.png)


### Creating a classfifcation Report


```python
from sklearn.metrics import classification_report

# Generate a classification report

# For this to work we need y_pred as binary labels not as probabilities
y_pred_binary = predictions.argmax(axis=1)

report = classification_report(y_true, y_pred_binary, target_names=cm_plot_labels)

print(report)
```

                  precision    recall  f1-score   support
    
        a_no_idc       0.50      1.00      0.67        21
       b_has_idc       0.00      0.00      0.00        21
    
        accuracy                           0.50        42
       macro avg       0.25      0.50      0.33        42
    weighted avg       0.25      0.50      0.33        42
    
    

    C:\Users\Subhash Kumar\anaconda3\lib\site-packages\sklearn\metrics\_classification.py:1221: UndefinedMetricWarning: Precision and F-score are ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, msg_start, len(result))
    

**Recall** = Given a class, will the classifier be able to detect it?<br>
**Precision** = Given a class prediction from a classifier, how likely is it to be correct?<br>
**F1 Score** = The harmonic mean of the recall and precision. Essentially, it punishes extreme values.

### Conclusion

* From the above report we can see that the model gives us admirable results.

* The model can be improved.

* The recall for each class should be ideally be above 0.90

* The present recall which the model produces is good enough.

* For use in the real world the recall can be further improved.

* This model can help pathologists detect cancer on tissue faster

* The manual examining of tissue slides would not be required
